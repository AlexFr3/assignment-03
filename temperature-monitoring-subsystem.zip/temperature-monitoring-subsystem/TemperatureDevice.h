#ifndef __TEMPERATUREDEVICE__
#define __TEMPERATUREDEVICE__

class TemperatureDevice {
public:
  virtual float getTemperature() = 0;   
};

#endif